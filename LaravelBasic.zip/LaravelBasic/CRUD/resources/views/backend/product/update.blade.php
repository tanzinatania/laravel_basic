@include("backend.includes.header")

    <section class="content mt-3">
      <div class="container-fluid">
        <div class="row">
          <div class="col-md-6 offset-md-3">

            <!-- my content -->
            <div class="card card-primary">
              <div class="card-header bg-info">
                <h3 class="card-title">Edit Product</h3>
              </div>
              <!-- /.card-header -->
              <!-- form start -->
            
              <form action="{{ route('update', $edit->id) }}" method="POST">
              @csrf
                <div class="card-body">
                  <div class="form-group mt-3">
                    <label for="name">Product Name</label>
                    <input name ="name" type="text" value="{{ $edit->name }}" class="form-control" placeholder="Enter Product Name">
                  </div>
                  <div class="form-group mt-3">
                    <label for="des">Product Description</label>
                    <textarea name ="des" type="text" value="{{ $edit->des }}" class="form-control" placeholder="Enter Product Description"></textarea>
                  </div>
                  <div class="form-group mt-3">
                    <label for="barcode">Barcode</label>
                    <input name ="barcode" type="text" value="{{ $edit->barcode }}" class="form-control">
                  </div>
                  <div class="form-group mt-3">
                    <label for="costprice">Cost Price</label>
                    <input name ="costprice" type="number" value="{{ $edit->costprice }}" class="form-control" placeholder="Enter Cost Price">
                  </div>
                  <div class="form-group mt-3">
                    <label for="saleprice">Sale Price</label>
                    <input name="saleprice" type="number" value="{{ $edit->saleprice }}" class="form-control" placeholder="Enter Sale Price">
                  </div>
                  <div class="form-group mt-3">
                    <label for="status">Status</label>
                    <select name="status" class="form-control">
                      <option value="1" @if ($edit->status == 1) selected @endif>Active</option>
                      <option value="2" @if ($edit->status == 2) selected @endif>Inactive</option>
                    </select>
				          </div>
                </div>
                <!-- /.card-body -->

                <div class="card-footer">
                  <button class="btn btn-primary">Update</button>
                </div>
              </form>
            </div>

          </div>
        </div>
        <!-- /.row -->
      </div><!--/. container-fluid -->
    </section>
@include("backend.includes.footer")