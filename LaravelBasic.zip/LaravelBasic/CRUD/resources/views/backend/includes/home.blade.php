@include("backend.includes.header")
    <h1>Welcome to my Page</h1>
@include("backend.includes.footer")
