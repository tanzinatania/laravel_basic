<?php echo $__env->make("includes.header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- <form action="<?php echo e(route('addproduct')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <input type="text" name="name" placeholder="Enter Name">
        <input type="text" name="des" placeholder="Enter Name">
        <select name="status" id="">
            <option value="1">Active</option>
            <option value="2">Inactive</option>
        </select>
        <button>Add</button>
    </form> -->

    <section class="content mt-3">
      <div class="container-fluid">
        <div class="row">
          <div class="col-md-6 offset-md-3">

            <!-- my content -->
            <div class="card card-primary">
              <div class="card-header bg-info">
                <h3 class="card-title">Add Product</h3>
              </div>
              <!-- /.card-header -->
              <!-- form start -->
            
              <form action="<?php echo e(route('addproduct')); ?>" method="POST">
              <?php echo csrf_field(); ?>
                <div class="card-body">
                  <div class="form-group mt-3">
                    <label for="name">Product Name</label>
                    <input name ="name" type="text" class="form-control" placeholder="Enter Product Name">
                  </div>
                  <div class="form-group mt-3">
                    <label for="des">Product Description</label>
                    <textarea name ="des" type="text" class="form-control" placeholder="Enter Product Description"></textarea>
                  </div>
                  <div class="form-group mt-3">
                    <label for="barcode">Barcode</label>
                    <input name ="barcode" type="text" class="form-control">
                  </div>
                  <div class="form-group mt-3">
                    <label for="costprice">Cost Price</label>
                    <input name ="costprice" type="number" class="form-control" placeholder="Enter Cost Price">
                  </div>
                  <div class="form-group mt-3">
                    <label for="saleprice">Sale Price</label>
                    <input name="saleprice" type="number" class="form-control" placeholder="Enter Sale Price">
                  </div>
                  <div class="form-group mt-3">
						<label for="status">Status</label>
						<select name="status" class="form-control">
							<option value="">----Select Status----</option>
							<option value="1">Active</option>
							<option value="2">Inactive</option>
						</select>
				    </div>
                </div>
                <!-- /.card-body -->

                <div class="card-footer">
                  <button class="btn btn-primary">Add</button>
                </div>
              </form>
            </div>

          </div>
        </div>
        <!-- /.row -->
      </div><!--/. container-fluid -->
    </section>
<?php echo $__env->make("includes.footer", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\LaravelBasic\CRUD\resources\views/addproduct.blade.php ENDPATH**/ ?>