<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html><?php /**PATH E:\xampp\htdocs\LaravelBasic\CRUD\resources\views/includes/footer.blade.php ENDPATH**/ ?>