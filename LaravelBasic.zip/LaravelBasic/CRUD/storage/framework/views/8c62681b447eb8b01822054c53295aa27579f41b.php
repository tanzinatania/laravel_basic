<?php echo $__env->make("backend.includes.header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <h1>All Products</h1>
    <a class="btn btn-primary btn-sm m-3" href="<?php echo e(route('product')); ?>">Add New</a>
    <table class="table" border="1">
        <thead>
            <tr>
                <th>#Sl No</th>
                <th>Product Name</th>
                <th>Product Description</th>
                <th>Barcode</th>
                <th>Cost Price</th>
                <th>Sale Price</th>
                <th>Status</th>
                <th colspan="2">Action</th>
            </tr>
        </thead>
        
        <?php $sl=1 ?>
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
            <tr>
                <td><?php echo e($sl); ?></td>
                <td><?php echo e($product->name); ?></td>
                <td><?php echo e($product->des); ?></td>
                <td><?php echo e($product->barcode); ?></td>
                <td><?php echo e($product->costprice); ?></td>
                <td><?php echo e($product->saleprice); ?></td>
                <td><?php if($product->status==1): ?>
                    <a class="btn btn-sm btn-success" href="<?php echo e(route('active', $product->id)); ?>">Active</a>
                <?php else: ?>
                    <a class="btn btn-sm btn-warning" href="<?php echo e(route('inactive', $product->id)); ?>">Inactive</a>
                <?php endif; ?>
                </td>
                <td><a class="btn btn-sm btn-info" href="<?php echo e(route('edit', $product->id)); ?>"><i class="fa fa-edit"></i></a>
                <button class='btn-sm btn btn-danger' data-bs-toggle='modal' data-bs-target='#delete<?php echo e($product->id); ?>'><i class="fa fa-trash"></i></button></td>
            </tr>
            <?php $sl++; ?>
    <!-- Modal -->
    <div class="modal fade" id="delete<?php echo e($product->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Confirmation Message</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
            Are you sure want to delete this item?
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
            <a href="<?php echo e(route('delete', $product->id)); ?>" type="button" class="btn btn-primary">Confirm</a>
        </div>
        </div>
    </div>
    </div>
            
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
<?php echo $__env->make("backend.includes.footer", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\LaravelBasic\CRUD\resources\views/backend/product/manage.blade.php ENDPATH**/ ?>