<?php echo $__env->make("backend.includes.header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
  <h1>All Products</h1>
  <a class="btn btn-info mb-3" href="<?php echo e(Route('subcategory')); ?>">Add New</a>
  <table class="table" border="1">
    <tr>
      <th>#Sl No</th>
      <th>Category Id</th>
      <th>Category Name</th>
      <th>Sub Category Name</th>
      <th>Description</th>
      <th>Image</th>
      <th>Status</th>
      <th colspan="2">Action</th>
    </tr>
    <?php $sl=1; ?>
    <?php $__currentLoopData = $SubCats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <td><?php echo e($sl); ?></td>
      <td><?php echo e($subcat->cat_id); ?></td>
      <td><?php echo e($subcat->catName->name); ?></td>
      <td><?php echo e($subcat->name); ?></td>
      <td><?php echo e($subcat->des); ?></td>
      <td><img src=" <?php echo e(asset('backend/subcatimage/'.$subcat->image)); ?> " alt="" height="30"></td>
      <!-- <td><?php echo e($subcat->status); ?></td> -->
      <td><?php if($subcat->status==1): ?>
          <a class="btn btn-sm btn-success" href="<?php echo e(route('activesubcat', $subcat->id)); ?>">Active</a>
      <?php else: ?>
          <a class="btn btn-sm btn-warning" href="<?php echo e(route('inactivesubcat', $subcat->id)); ?>">Inactive</a>
      <?php endif; ?>
      </td>
      <td><a class="btn btn-info btn-sm" href="<?php echo e(route('editsubcat',$subcat->id)); ?>">Edit</a>
      <a class="btn btn-danger btn-sm" href="<?php echo e(route('deletesubcat',$subcat->id)); ?>">Delete</a></td>
    </tr>
    <?php $sl++; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </table>
  <?php echo $__env->make("backend.includes.footer", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 

<?php /**PATH E:\xampp\htdocs\LaravelBasic\CRUD\resources\views/backend/subcategory/manage.blade.php ENDPATH**/ ?>