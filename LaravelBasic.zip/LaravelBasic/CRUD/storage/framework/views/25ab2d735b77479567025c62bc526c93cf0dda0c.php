<?php echo $__env->make("backend.includes.header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <h1>Welcome to my Page</h1>
<?php echo $__env->make("backend.includes.footer", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH E:\xampp\htdocs\LaravelBasic\CRUD\resources\views/backend/includes/home.blade.php ENDPATH**/ ?>