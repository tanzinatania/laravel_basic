<?php echo $__env->make("backend.includes.header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- <form action="<?php echo e(route('update', $edit->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <input type="text" value="<?php echo e($edit->name); ?>" name="name" placeholder="Enter Name">
        <input type="text" value="<?php echo e($edit->des); ?>" name="des" placeholder="Enter Name">
        <select name="status" id="">
            <option value="1" <?php if($edit->status == 1): ?> selected <?php endif; ?>>Active</option>
            <option value="2" <?php if($edit->status == 2): ?> selected <?php endif; ?>>Inactive</option>
        </select>
        <button>Save Change</button>
    </form> -->

    <section class="content mt-3">
      <div class="container-fluid">
        <div class="row">
          <div class="col-md-6 offset-md-3">

            <!-- my content -->
            <div class="card card-primary">
              <div class="card-header bg-info">
                <h3 class="card-title">Edit Product</h3>
              </div>
              <!-- /.card-header -->
              <!-- form start -->
            
              <form action="<?php echo e(route('update', $edit->id)); ?>" method="POST">
              <?php echo csrf_field(); ?>
                <div class="card-body">
                  <div class="form-group mt-3">
                    <label for="name">Product Name</label>
                    <input name ="name" type="text" value="<?php echo e($edit->name); ?>" class="form-control" placeholder="Enter Product Name">
                  </div>
                  <div class="form-group mt-3">
                    <label for="des">Product Description</label>
                    <textarea name ="des" type="text" value="<?php echo e($edit->des); ?>" class="form-control" placeholder="Enter Product Description"></textarea>
                  </div>
                  <div class="form-group mt-3">
                    <label for="barcode">Barcode</label>
                    <input name ="barcode" type="text" value="<?php echo e($edit->barcode); ?>" class="form-control">
                  </div>
                  <div class="form-group mt-3">
                    <label for="costprice">Cost Price</label>
                    <input name ="costprice" type="number" value="<?php echo e($edit->costprice); ?>" class="form-control" placeholder="Enter Cost Price">
                  </div>
                  <div class="form-group mt-3">
                    <label for="saleprice">Sale Price</label>
                    <input name="saleprice" type="number" value="<?php echo e($edit->saleprice); ?>" class="form-control" placeholder="Enter Sale Price">
                  </div>
                  <div class="form-group mt-3">
                    <label for="status">Status</label>
                    <select name="status" class="form-control">
                      <option value="1" <?php if($edit->status == 1): ?> selected <?php endif; ?>>Active</option>
                      <option value="2" <?php if($edit->status == 2): ?> selected <?php endif; ?>>Inactive</option>
                    </select>
				          </div>
                </div>
                <!-- /.card-body -->

                <div class="card-footer">
                  <button class="btn btn-primary">Update</button>
                </div>
              </form>
            </div>

          </div>
        </div>
        <!-- /.row -->
      </div><!--/. container-fluid -->
    </section>
<?php echo $__env->make("backend.includes.footer", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\LaravelBasic\CRUD\resources\views/backend/product/update.blade.php ENDPATH**/ ?>