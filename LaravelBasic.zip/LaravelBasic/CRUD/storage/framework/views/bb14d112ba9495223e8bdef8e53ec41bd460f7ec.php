<?php echo $__env->make("backend.includes.header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
  <div class="container">
    <div class="row">
      <form action="<?php echo e(route('updatesubcat',$SubCats->id)); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
      <div class="col-md-8 offset-md-2">
        <div class="form-group">
          <label for="">Select Category</label>
          <select name="cat_id" id="" class="form-control">
            <?php $__currentLoopData = $cats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($cat->id); ?>"><?php echo e($cat->name); ?></option>  
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
        </div>
        <div class="form-group">
          <label for="">Sub-Category Name</label>
          <input type="text" class="form-control" value="<?php echo e($SubCats->name); ?>" name="name">
        </div>
        <div class="form-group">
          <label for="">Description</label>
          <input type="text" class="form-control" value="<?php echo e($SubCats->des); ?>" name="des">
        </div>
        <div class="form-group">
          <img height="100" src="<?php echo e(asset('backend/subcatimage/'.$SubCats->image)); ?>" alt="">
        </div>
        <div class="form-group">
          <label for="">Image</label>
          <input type="file" class="form-control" name="pic">
        </div>
        <div class="form-group">
          <label for="">Select Status</label>
          <select name="status" id="" class="form-control">
              <option value="">----Select Status -----</option>
              <option value="1" <?php if($SubCats->status == 1): ?> selected <?php endif; ?>>Active</option>
              <option value="2" <?php if($SubCats->status == 2): ?> selected <?php endif; ?>>Inactive</option>
          </select>
        </div>
        <button class="btn btn-info mt-2">Add Item</button>
      </div>
      </form>
    </div>
  </div>  
<?php echo $__env->make("backend.includes.footer", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> <?php /**PATH E:\xampp\htdocs\LaravelBasic\CRUD\resources\views/backend/subcategory/edit.blade.php ENDPATH**/ ?>