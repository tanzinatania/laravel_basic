<?php

namespace App\Http\Controllers\Backend;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Backend\Category;
use App\Models\Backend\SubCategory;
use Image;
use File;

class SubcatController extends Controller
{
    public function index(){
        $cats = Category::all();
        return view("backend/subcategory/add", compact("cats"));
    }

    public function add(Request $rqst){
       
        if($rqst->pic){
            $image = $rqst->file('pic');
            $customName = rand().".".$image->getClientOriginalExtension();
            $location = public_path('backend/subcatimage/'.$customName);
            Image::make($image)->save($location);
        }
        $subcat = new SubCategory;
        $subcat->cat_id = $rqst->cat_id;
        $subcat->name = $rqst->name;
        $subcat->des = $rqst->des;
        $subcat->image = $customName;
        $subcat->status = $rqst->status;
        $subcat->save();
        // dd($subcat);
        return redirect()->route("showsubcat");
    }

    public function show(){
        $SubCats = SubCategory::all();
        return view("backend.subcategory.manage",compact("SubCats"));
    }

    public function findData($id){
        $SubCats = SubCategory::find($id);
        $cats = Category::all();
        return view("backend.subcategory.edit",compact("SubCats","cats"));
    }

    public function delete($id){
        $delete = SubCategory::find($id);
        if(File::exists("backend/subcatimage/".$delete->image)){
            File::delete("backend/subcatimage/".$delete->image);
        }
        $delete->delete();
        return back();
    }
    public function update(Request $rqst, $id){
        $subcat = SubCategory::find($id);
        if($rqst->pic){
            if(File::exists("backend/subcatimage/".$subcat->image)){
                File::delete("backend/subcatimage/".$subcat->image);
                $image = $rqst->file('pic');
                $customName = rand().".".$image->getClientOriginalExtension();
                $location = public_path('backend/subcatimage/'.$customName);
                Image::make($image)->save($location);
                $subcat->image = $customName;
            }
        }
        $subcat->cat_id = $rqst->cat_id;
        $subcat->name = $rqst->name;
        $subcat->des = $rqst->des;
        $subcat->status = $rqst->status;
        $subcat->update();
        return redirect()->route("showsubcat");
    }

    public function active($id)
    {
        $active = SubCategory::find($id);
        $active->status=2;
        $active->update();
        return back();
    }

    public function inactive($id)
    {
        $inactive = SubCategory::find($id);
        $inactive->status=1;
        $inactive->update();
        return back();
    }
}
