<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Backend\ProductCOntroller;
use App\Http\Controllers\Backend\CategoryController;
use App\Http\Controllers\Backend\SubcatController;
use App\Http\Controllers\Backend\ItemController;

// Route::get('/', function () {
//     return view('welcome');
// });

Route::get('/',[ProductCOntroller::class, 'home'])->name("home");
Route::get('/product',[ProductCOntroller::class, 'index'])->name("product");
Route::post('/addproduct',[ProductCOntroller::class, 'insert'])->name("addproduct");
Route::get('/showproduct',[ProductCOntroller::class, 'show'])->name("showproduct");
Route::get('/delete/{id}',[ProductCOntroller::class, 'delete'])->name("delete");
Route::get('/edit/{id}',[ProductCOntroller::class, 'edit'])->name("edit");
Route::post('/update/{id}',[ProductCOntroller::class, 'update'])->name("update");
Route::get('/active/{id}',[ProductCOntroller::class, 'active'])->name("active");
Route::get('/inactive/{id}',[ProductCOntroller::class, 'inactive'])->name("inactive");
Route::get('/category',[CategoryController::class,'create'])->name("category");
Route::post('/addcategory',[CategoryController::class,'insert']);
Route::get('/showcategory',[CategoryController::class,'show']);
Route::get('/deletecategory/{id}',[CategoryController::class,'delete']);
Route::get('/editcategory/{id}',[CategoryController::class,'edit']);
Route::post('/updatecategory/{id}',[CategoryController::class,'update']);
Route::get('/activecategory/{id}',[CategoryController::class,'active']);
Route::get('/inactivecategory/{id}',[CategoryController::class,'inactive']);
Route::get('/subcategory',[SubcatController::class,'index'])->name("subcategory");
Route::post('/addsubcat',[SubcatController::class,'add'])->name("addsubcat");
Route::get('/showsubcat',[SubcatController::class,'show'])->name("showsubcat");

Route::get('/deletesubcat/{id}',[SubcatController::class,'delete'])->name("deletesubcat");
Route::get('/editsubcat/{id}',[SubcatController::class,'findData'])->name("editsubcat");

Route::post('/updatesubcat/{id}',[SubcatController::class,'update'])->name("updatesubcat");
Route::get('/activesubcat/{id}',[SubcatController::class,'active'])->name("activesubcat");
Route::get('/inactivesubcat/{id}',[SubcatController::class,'inactive'])->name("inactivesubcat");

Route::get('/additem',[ItemController::class,'index'])->name("additem");
Route::post('/insertitem',[ItemController::class,'insert'])->name("insertitem");
Route::get('/showitem',[ItemController::class,'show'])->name("showitem");
Route::get('/edititem/{id}',[ItemController::class,'edit'])->name("edititem");
Route::get('/deletegallery/{id}',[ItemController::class,'deleteGallery'])->name("deletegallery");

Route::post('/addnewGallery/{id}',[ItemController::class,'addnewGallery'])->name("addnewGallery");



